# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
WebTutor::Application.config.secret_token = '9e29a271a8ec8760f3c04df3c15057ae2e3edbf5926b5d7d5342dcd5d0e5b7bfbb90bd1264070e5e49e3ae0262a426ba3000e66e26edb4ef32b47b9aa30f24f6'
